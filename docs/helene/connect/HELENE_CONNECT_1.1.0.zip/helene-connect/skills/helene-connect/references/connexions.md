# Connexions facultatives

## Principe

HÉLÈNE CONNECT 1.1.0 fournit des instructions, des références et des calculateurs facultatifs. Il ne provisionne ni serveur, ni coffre, ni synchronisation, ni outil MCP. Il n'embarque aucune clé, aucun identifiant de compte, aucune adresse de service privé ni liaison aux apps de Nicolas.

Le raisonnement conversationnel reste celui du modèle utilisé par ChatGPT. La méthode SUPRA structure le travail ; elle ne démontre aucun appel à SuperModel, X10, SHERPA, PRISM, MOTHER ou à une autre IA.

## Avant un appel externe

Vérifier dans le contexte actuel :

| Élément | Preuve utile |
| --- | --- |
| Outil | Nom exact et schéma réellement exposés |
| Compte | Connexion authentifiée à utiliser, choisie sans ambiguïté |
| Ressource | Accès limité à la ressource concernée par la demande |
| Mandat | Action et informations couvertes par la demande actuelle ou une autorisation encore valable |
| Coût | Conditions du service ; pas de nouvelle dépense ou recharge implicite |
| Résultat | Réponse du fournisseur, date, état et identifiant si disponible |

Ces vérifications sont des règles de conduite et non une passerelle d'authentification. Seul le fournisseur accorde l'accès. Ne pas remplacer une permission inconnue par une autorisation déclarative dans un fichier JSON. Ne pas demander un mot de passe ou une clé API dans la conversation.

Pour les propres services d'Hélène, réutiliser ses connexions disponibles. Si plusieurs comptes correspondent à une écriture et que le choix est ambigu, demander lequel. Ne pas hériter d'un autre utilisateur les identifiants, les cookies, les tokens, les liens privés ou les droits.

## Accomplir l'action sans parcours de configuration inutile

Privilégier la fonction native ou l'app qui réalise directement la demande. Rechercher seulement cette capacité ; ne pas demander de connecter toutes les apps avant de commencer. Une demande explicite et suffisamment précise autorise l'action bornée : préparer puis exécuter sans confirmation répétée.

Si la fonction n'est pas exposée, livrer le résultat utilisable en conversation et nommer la limite précise. Si une app exposée demande réellement une autorisation, préparer le contenu, la ressource et le périmètre avant de lancer son parcours d'autorisation officiel. Expliquer en une phrase l'accès nécessaire. Ne pas remplacer un refus du fournisseur par une autre identité ou un nouveau service. Après autorisation, reprendre l'action demandée et vérifier son résultat.

Une seule information peut encore bloquer une action précise, par exemple le choix entre deux agendas. La demander directement ; ne pas lancer une série de questions d'accueil. En cas d'échec au résultat incertain, vérifier l'état avant toute nouvelle tentative.

Pour un service SUPRA partagé, obtenir à la fois l'autorisation du propriétaire sur la ressource et celle d'Hélène sur les données qu'elle transmet. Une autorisation générale « capacités SUPRA » ne désigne pas un dossier, un tiers destinataire ou un budget. En l'absence de liaison qualifiée, continuer avec les méthodes locales et préciser le raccord manquant, sans créer de serveur de remplacement.

## Actions utiles et statuts

- Agenda : préparer date, fuseau, durée et titre ; utiliser le connecteur autorisé si demandé et disponible ; relire le résultat. Signaler toute invitation à un tiers.
- Rappel : confirmer la date et le fuseau lorsqu'ils sont nécessaires ; utiliser une fonction de tâches programmées disponible ; annoncer « créé » seulement après le reçu.
- Message : rédiger librement ; envoyer seulement sur demande explicite couvrant le destinataire et le contenu.
- Documents : utiliser ceux fournis ou accessibles dans le périmètre demandé ; ne pas parcourir toutes les sources personnelles.
- Mémoire : enregistrer uniquement les éléments choisis par Hélène dans un espace identifié ; distinguer fiche exportée et mémoire native.
- Simulation : préciser les entrées, hypothèses, calculs et limites. Qualifier un outil déterministe comme tel ; ne pas le présenter comme une prévision réelle.

Ne pas lancer de surveillance permanente ou de service autonome à partir du seul fait que le plugin est installé. Une programmation requiert une demande et un résultat du planificateur.
