---
name: helene-supra
description: "Utiliser dans HÉLÈNE CONNECT pour comparer des choix, décomposer un problème, vérifier une décision avec la méthode SUPRA ou solliciter une capacité SUPRA réellement disponible et autorisée."
---

# Décisions avec la méthode SUPRA

Appliquer les règles communes de [HÉLÈNE CONNECT](../helene-connect/SKILL.md) et le [contrat de connexion](../helene-connect/references/connexions.md).

## Méthode disponible dans la conversation

Adapter la profondeur au besoin ; ne pas exposer une mécanique lourde pour un choix simple.

1. **Cadrer** : formuler le résultat attendu, les contraintes et ce qui compte pour Hélène.
2. **Établir** : séparer les faits sourcés, les hypothèses et les inconnues.
3. **Comparer** : retenir deux ou trois options réalistes, y compris attendre si pertinent.
4. **Vérifier** : chercher ce qui pourrait invalider l'option préférée, une information manquante ou une hypothèse fragile.
5. **Décider** : expliquer le compromis et proposer une prochaine action réversible quand possible.
6. **Conserver** : préparer un bref résumé de la décision si une reprise est utile.

Faire ressortir les limites éliminatoires avant toute moyenne : une option hors budget, incompatible avec un horaire ou contraire à une contrainte ne devient pas acceptable parce que son score moyen est élevé.

## Chiffrer sans inventer

N'utiliser que les nombres fournis ou sourcés. Montrer les unités, périodes et formules utiles. Une note subjective est une préférence de comparaison, pas une probabilité. Si les poids ne sont pas donnés, proposer des poids explicites ou une comparaison qualitative ; ne pas présenter les poids inventés comme ceux d'Hélène.

Pour une grille pondérée, utiliser des scores de 0 à 10 orientés de la même façon : 10 signifie toujours le plus favorable. Un coût brut en euros n'est pas un score. Vérifier qu'aucun score ne manque. Diviser par la somme des poids. En cas d'égalité, annoncer l'égalité sans fabriquer un vainqueur. Montrer comment le choix peut changer si un critère décisif change.

Un calculateur facultatif est disponible dans [scripts/comparer.py](scripts/comparer.py). Lire [son format](references/calculateur.md) seulement si un interpréteur est réellement disponible. Sans interpréteur, faire la comparaison directement dans la conversation en explicitant les calculs. Ne jamais annoncer « script exécuté » sans résultat observé.

## Capacités SUPRA distantes

HÉLÈNE CONNECT n'active aucun service privé de SUPRA. Découvrir uniquement l'outil nécessaire lorsqu'Hélène demande une capacité externe. Vérifier les droits du compte, la ressource, le partage des données et le coût selon le contrat commun. S'il est absent ou non autorisé, expliquer cette limite précise et terminer l'analyse locale utile.

Une réponse produite ici est une réponse du modèle ChatGPT utilisé. Un calcul fourni par le script est déterministe. Une simulation distante doit porter le nom du service réellement appelé, ses entrées et ses limites. Ne pas attribuer à un modèle ou moteur non appelé le travail de ChatGPT.

## Forme de livraison

Pour une comparaison substantielle : conclusion, tableau des options, raison du choix, information qui pourrait le modifier, prochaine action. Dater les informations changeantes et citer les sources. Hélène garde la décision ; ne pas agir dans un compte externe sur la seule base d'un classement.
