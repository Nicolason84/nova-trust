# Calculateur facultatif de comparaison

Ce programme utilise uniquement Python 3 et sa bibliothèque standard. Il lit un objet JSON sur l'entrée standard, calcule une moyenne pondérée et écrit du JSON. Il ne lit aucun fichier, n'appelle aucun réseau et ne conserve aucune donnée. L'environnement qui exécute le programme peut conserver son propre historique ; ne pas promettre l'effacement de cet historique.

Il ne constitue ni une IA supplémentaire, ni un outil MCP, ni un système d'autorisation. Les contraintes éliminatoires doivent être traitées avant le classement. Dans Chat standard sans exécution de scripts, utiliser la méthode décrite dans la compétence.

## Entrée

Exemple entièrement fictif :

```json
{
  "criteria": [
    {"name": "confort", "weight": 2},
    {"name": "souplesse", "weight": 1}
  ],
  "options": [
    {"name": "A", "scores": {"confort": 8, "souplesse": 5}},
    {"name": "B", "scores": {"confort": 6, "souplesse": 9}}
  ]
}
```

Les noms sont uniques, de 1 à 100 caractères, sans espaces extérieurs. Chaque poids est un nombre fini strictement positif, au plus 1 000 000. Chaque score est un nombre fini entre 0 et 10. Les nombres comportent au plus 28 chiffres et un exposant décimal compris entre -12 et 12. Chaque option doit donner exactement les critères attendus. Les booléens, valeurs manquantes, champs supplémentaires et doublons sont rejetés. Deux à vingt options et un à vingt critères sont acceptés. Le JSON d'entrée ne peut excéder 100 000 octets.

## Calcul

Pour chaque option : `somme(poids × score) / somme(poids)`.
Dans l'exemple, A = 7 et B = 7 : le résultat signale une égalité. Le classement utilise les fractions exactes des valeurs décimales fournies ; l'affichage arrondit à six décimales. Deux valeurs affichées identiques après arrondi peuvent rester différentes exactement.

Invocation dans un environnement autorisé : `python3 comparer.py`, avec l'objet JSON sur l'entrée standard. Une erreur d'entrée produit `ok: false` et un code de sortie 2, sans recopier le contenu d'entrée. Une réussite produit `ok: true`, le classement, la liste des meilleures options, les scores exacts et une limite d'interprétation.
