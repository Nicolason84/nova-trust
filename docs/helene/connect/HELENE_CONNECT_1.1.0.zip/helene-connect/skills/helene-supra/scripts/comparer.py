#!/usr/bin/env python3
"""Comparaison pondérée facultative, hors réseau et sans stockage applicatif."""

import json
import sys
from decimal import Decimal
from fractions import Fraction


class InputError(ValueError):
    pass


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise InputError("Clé JSON répétée.")
        result[key] = value
    return result


def reject_constant(_value):
    raise InputError("Les nombres doivent être finis.")


def record(value, expected):
    if not isinstance(value, dict) or set(value) != set(expected):
        raise InputError("Structure ou champs non conformes au format documenté.")
    return value


def name(value):
    if not isinstance(value, str) or not value or value != value.strip() or len(value) > 100:
        raise InputError("Nom invalide : fournir un texte de 1 à 100 caractères sans espaces extérieurs.")
    return value


def number(value, maximum, positive=False):
    if not isinstance(value, Decimal) or not value.is_finite():
        raise InputError("Un nombre décimal fini est requis ; les booléens sont interdits.")
    parts = value.as_tuple()
    if len(parts.digits) > 28 or not -12 <= parts.exponent <= 12:
        raise InputError("Précision numérique excessive : 28 chiffres et exposant de -12 à 12 maximum.")
    if value < 0 or value > maximum or (positive and value == 0):
        raise InputError("Poids ou score en dehors de la plage autorisée.")
    return Fraction(value)


def compare(data):
    record(data, {"criteria", "options"})
    criteria, options = data["criteria"], data["options"]
    if not isinstance(criteria, list) or not 1 <= len(criteria) <= 20:
        raise InputError("Fournir de 1 à 20 critères.")
    if not isinstance(options, list) or not 2 <= len(options) <= 20:
        raise InputError("Fournir de 2 à 20 options.")
    weights = {}
    for criterion in criteria:
        record(criterion, {"name", "weight"})
        label = name(criterion["name"])
        if label in weights:
            raise InputError("Les critères doivent avoir des noms uniques.")
        weights[label] = number(criterion["weight"], Decimal(1000000), positive=True)
    total_weight = sum(weights.values(), Fraction())
    seen = set()
    results = []
    for option in options:
        record(option, {"name", "scores"})
        label = name(option["name"])
        if label in seen:
            raise InputError("Les options doivent avoir des noms uniques.")
        seen.add(label)
        scores = record(option["scores"], weights)
        weighted = sum((weight * number(scores[key], Decimal(10))
                        for key, weight in weights.items()), Fraction())
        results.append((label, weighted / total_weight))
    results.sort(key=lambda item: item[1], reverse=True)
    best = results[0][1]
    leaders = [label for label, score in results if score == best]
    ranking = []
    for label, score in results:
        rank = 1 + sum(other_score > score for _, other_score in results)
        ranking.append({"name": label, "rank": rank, "score": round(float(score), 6),
                        "score_exact": str(score)})
    return {"ok": True, "method": "weighted_mean", "scale": [0, 10],
            "ranking": ranking, "leaders": leaders, "tie": len(leaders) > 1,
            "limitation": "Classement fondé sur les poids et notes fournis ; aucune probabilité ni prédiction. Traiter les contraintes éliminatoires séparément."}


def main():
    try:
        raw = sys.stdin.buffer.read(100001)
        if len(raw) > 100000:
            raise InputError("Entrée supérieure à 100 000 octets.")
        data = json.loads(raw.decode("utf-8"), parse_float=Decimal, parse_int=Decimal,
                          parse_constant=reject_constant, object_pairs_hook=unique_object)
        result = compare(data)
        code = 0
    except (InputError, ValueError, TypeError, UnicodeError, RecursionError):
        result = {"ok": False, "error": "Entrée invalide. Vérifier le format, les noms uniques, les critères complets et les limites numériques documentées."}
        code = 2
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    return code


if __name__ == "__main__":
    sys.exit(main())
