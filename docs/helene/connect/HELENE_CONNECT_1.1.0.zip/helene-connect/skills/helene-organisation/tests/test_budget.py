"""Tests déterministes avec données fictives ; aucune connexion ni écriture de fichier."""

import importlib.util
import json
import subprocess
import sys
import unittest
from decimal import localcontext
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "budget.py"
SPEC = importlib.util.spec_from_file_location("helene_budget", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def calculate(raw):
    return MODULE.budget(MODULE.parse_input(raw.encode("utf-8")))


class BudgetTests(unittest.TestCase):
    def test_time_deficit_includes_reserve_once(self):
        result = calculate('''{
            "unit": "minutes", "available": 60, "reserve": 10,
            "items": [{"name": "Dossier", "amount": 40},
                      {"name": "Courses", "amount": 30},
                      {"name": "Cuisine", "amount": 20}]
        }''')
        self.assertEqual(result["usable"], "50")
        self.assertEqual(result["total"], "90")
        self.assertEqual(result["balance"], "-40")
        self.assertEqual(result["deficit"], "40")
        self.assertEqual(result["unallocated"], "0")
        self.assertFalse(result["fits"])

    def test_money_remainder(self):
        result = calculate('''{
            "unit": "EUR", "available": 100, "reserve": 10,
            "items": [{"name": "Courses", "amount": 19.99},
                      {"name": "Transport", "amount": 20.01}]
        }''')
        self.assertEqual(result["total"], "40")
        self.assertEqual(result["balance"], "50")
        self.assertEqual(result["unallocated"], "50")
        self.assertEqual(result["deficit"], "0")
        self.assertTrue(result["fits"])

    def test_decimal_exact_fit_with_default_reserve(self):
        result = calculate('''{
            "unit": "EUR", "available": 0.3,
            "items": [{"name": "A", "amount": 0.1},
                      {"name": "B", "amount": 0.2}]
        }''')
        self.assertEqual(result["total"], "0.3")
        self.assertEqual(result["reserve"], "0")
        self.assertEqual(result["balance"], "0")
        self.assertTrue(result["fits"])

    def test_empty_budget_and_oversized_reserve(self):
        result = calculate('{"unit":"minutes","available":5,"reserve":10,"items":[]}')
        self.assertEqual(result["total"], "0")
        self.assertEqual(result["usable"], "-5")
        self.assertEqual(result["deficit"], "5")
        self.assertFalse(result["fits"])
        empty = calculate('{"unit":"EUR","available":0,"items":[]}')
        self.assertEqual(empty["balance"], "0")
        self.assertTrue(empty["fits"])

    def test_large_sum_and_small_fraction_are_exact(self):
        data = {
            "unit": "minutes", "available": 1000000000000,
            "items": [{"name": str(i), "amount": 1000000000000} for i in range(1000)],
        }
        with localcontext() as context:
            context.prec = 6
            result = calculate(json.dumps(data))
            small = calculate('''{
                "unit":"EUR","available":1,"reserve":0.000000000001,
                "items":[{"name":"A","amount":0.999999999999}]
            }''')
        self.assertEqual(result["total"], "1000000000000000")
        self.assertEqual(result["deficit"], "999000000000000")
        self.assertEqual(small["balance"], "0")
        self.assertTrue(small["fits"])

    def test_rejects_invalid_numbers(self):
        values = ["true", "null", '"20"', "-1", "NaN", "Infinity", "-Infinity",
                  "1000000000001", "1e-13", "1e13", "0.12345678901234567890123456789"]
        for value in values:
            for field in ("available", "reserve", "amount"):
                with self.subTest(value=value, field=field):
                    if field == "amount":
                        raw = '{"unit":"EUR","available":100,"items":[{"name":"A","amount":' + value + '}]}'
                    else:
                        raw = '{"unit":"EUR","available":100,"reserve":0,"items":[]}'
                        raw = raw.replace('"' + field + '":' + ("100" if field == "available" else "0"),
                                          '"' + field + '":' + value)
                    with self.assertRaises((MODULE.InputError, ValueError)):
                        calculate(raw)

    def test_rejects_malformed_shapes(self):
        invalid = [
            '[]',
            '{"unit":"EUR","items":[]}',
            '{"unit":"EUR","available":1,"items":[],"extra":1}',
            '{"unit":"EUR","available":1,"items":{}}',
            '{"unit":"EUR","available":1,"items":[{"name":"A"}]}',
            '{"unit":"EUR","available":1,"items":[{"name":"A","amount":0,"extra":1}]}',
            '{"unit":"","available":1,"items":[]}',
            '{"unit":" EUR","available":1,"items":[]}',
            '{"unit":"EUR","available":1,"items":[{"name":" A","amount":0}]}',
            '{"unit":"EUR","available":1,"items":[{"name":"A","amount":0},{"name":"A","amount":1}]}',
        ]
        for raw in invalid:
            with self.subTest(raw=raw), self.assertRaises(MODULE.InputError):
                calculate(raw)

    def test_rejects_duplicate_json_keys(self):
        for raw in (
            '{"unit":"EUR","available":10,"available":20,"items":[]}',
            '{"unit":"EUR","available":10,"items":[{"name":"A","amount":1,"amount":2}]}',
        ):
            with self.subTest(raw=raw), self.assertRaises(MODULE.InputError):
                calculate(raw)

    def test_rejects_excessive_item_count_and_input_size(self):
        data = {"unit": "EUR", "available": 1,
                "items": [{"name": str(i), "amount": 0} for i in range(1001)]}
        with self.assertRaises(MODULE.InputError):
            calculate(json.dumps(data))
        with self.assertRaises(MODULE.InputError):
            MODULE.parse_input(b" " * 100001)

    def test_cli_success_preserves_unicode(self):
        process = subprocess.run(
            [sys.executable, str(SCRIPT)],
            input='{"unit":"unités","available":3,"items":[{"name":"Été","amount":1.5}]}'.encode("utf-8"),
            capture_output=True, check=False,
        )
        self.assertEqual(process.returncode, 0)
        result = json.loads(process.stdout)
        self.assertEqual(result["unit"], "unités")
        self.assertEqual(result["balance"], "1.5")
        self.assertEqual(process.stderr, b"")

    def test_cli_errors_do_not_echo_input_or_traceback(self):
        inputs = [
            b'{"unit":"EUR","available":1,"items":[{"name":"PRIVATE_MARKER","amount":-1}]}',
            b'{"unit":"EUR","available":1e999999999999999999999999999999999,"items":[]}',
            b'{"unit":"\\ud800","available":1,"items":[]}',
            b"\xff", b" " * 100001, b"[" * 1500 + b"]" * 1500,
        ]
        for raw in inputs:
            with self.subTest(raw_size=len(raw)):
                process = subprocess.run(
                    [sys.executable, str(SCRIPT)], input=raw,
                    capture_output=True, check=False,
                )
                self.assertEqual(process.returncode, 2)
                self.assertFalse(json.loads(process.stdout)["ok"])
                self.assertNotIn(b"PRIVATE_MARKER", process.stdout)
                self.assertEqual(process.stderr, b"")


if __name__ == "__main__":
    unittest.main()
