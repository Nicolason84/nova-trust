#!/usr/bin/env python3
"""Budget exact de temps ou de dépenses, hors réseau et sans stockage applicatif."""

import json
import sys
from decimal import Decimal, DecimalException, localcontext
from fractions import Fraction


MAX_INPUT_BYTES = 100000
MAX_AMOUNT = Decimal("1000000000000")


class InputError(ValueError):
    pass


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise InputError("Clé JSON répétée.")
        result[key] = value
    return result


def reject_constant(_value):
    raise InputError("Les montants doivent être finis.")


def record(value, required, optional=()):
    if (not isinstance(value, dict)
            or not set(required).issubset(value)
            or not set(value).issubset(set(required) | set(optional))):
        raise InputError("Structure ou champs non conformes au format documenté.")
    return value


def label(value, maximum=100):
    if (not isinstance(value, str) or not value or value != value.strip()
            or len(value) > maximum):
        raise InputError("Libellé invalide ou trop long.")
    value.encode("utf-8")
    return value


def amount(value):
    if not isinstance(value, Decimal) or not value.is_finite():
        raise InputError("Un nombre décimal fini est requis ; les booléens sont interdits.")
    parts = value.as_tuple()
    if len(parts.digits) > 28 or not -12 <= parts.exponent <= 12:
        raise InputError("Précision numérique excessive.")
    if value < 0 or value > MAX_AMOUNT:
        raise InputError("Montant négatif ou supérieur à la limite.")
    return Fraction(value)


def decimal_text(value):
    # Input bounds and the 1,000-item limit need fewer than 32 significant
    # decimal digits. Fractions keep arithmetic exact regardless of caller context.
    with localcontext() as context:
        context.prec = 64
        rendered = format(Decimal(value.numerator) / Decimal(value.denominator), "f")
    return rendered.rstrip("0").rstrip(".") if "." in rendered else rendered


def budget(data):
    record(data, {"unit", "available", "items"}, {"reserve"})
    unit = label(data["unit"], maximum=32)
    available = amount(data["available"])
    reserve = amount(data.get("reserve", Decimal(0)))
    items = data["items"]
    if not isinstance(items, list) or len(items) > 1000:
        raise InputError("Fournir une liste d'au plus 1 000 postes.")

    total = Fraction()
    seen = set()
    for item in items:
        record(item, {"name", "amount"})
        name = label(item["name"])
        if name in seen:
            raise InputError("Les postes doivent avoir des noms uniques.")
        seen.add(name)
        total += amount(item["amount"])

    usable = available - reserve
    balance = usable - total
    return {
        "ok": True,
        "method": "budget",
        "unit": unit,
        "available": decimal_text(available),
        "reserve": decimal_text(reserve),
        "usable": decimal_text(usable),
        "total": decimal_text(total),
        "balance": decimal_text(balance),
        "deficit": decimal_text(max(-balance, Fraction())),
        "unallocated": decimal_text(max(balance, Fraction())),
        "fits": balance >= 0,
        "limitation": (
            "Addition des montants fournis dans une même unité ; "
            "aucun arbitrage automatique, conversion ou programmation."
        ),
    }


def parse_input(raw):
    if len(raw) > MAX_INPUT_BYTES:
        raise InputError("Entrée supérieure à 100 000 octets.")
    return json.loads(raw.decode("utf-8"), parse_float=Decimal, parse_int=Decimal,
                      parse_constant=reject_constant, object_pairs_hook=unique_object)


def main():
    try:
        raw = sys.stdin.buffer.read(MAX_INPUT_BYTES + 1)
        result = budget(parse_input(raw))
        code = 0
    except (InputError, ValueError, TypeError, UnicodeError, RecursionError, DecimalException):
        result = {
            "ok": False,
            "error": (
                "Entrée invalide. Vérifier le format, les noms uniques, "
                "l'unité commune et les limites numériques documentées."
            ),
        }
        code = 2
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    return code


if __name__ == "__main__":
    sys.exit(main())
