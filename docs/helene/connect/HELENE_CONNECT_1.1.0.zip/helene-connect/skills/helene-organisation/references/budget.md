# Calculateur facultatif de budget

Utiliser ce calculateur pour additionner des durées ou des dépenses courantes connues et contrôler ce qui tient dans une enveloppe. Il utilise uniquement Python 3 et sa bibliothèque standard, lit du JSON sur l'entrée standard et renvoie du JSON. Il ne lit aucun fichier, ne crée ni fichier personnel ni rendez-vous, n'appelle aucun réseau et ne conserve aucune donnée. L'environnement d'exécution peut conserver son propre historique ; ne pas promettre son effacement.

Il ne choisit pas les priorités, ne vérifie pas les prix actuels, ne convertit pas les unités ou les devises et ne fournit pas de conseil d'investissement, fiscal ou de crédit. Sans interpréteur, appliquer la procédure conversationnelle ci-dessous.

## Entrée

Exemple entièrement fictif :

```json
{
  "unit": "minutes",
  "available": 60,
  "reserve": 10,
  "items": [
    {"name": "Dossier", "amount": 40},
    {"name": "Courses", "amount": 30},
    {"name": "Cuisine", "amount": 20}
  ]
}
```

`unit`, `available` et `items` sont obligatoires. `reserve` est facultatif et vaut zéro s'il manque. Une seule unité s'applique à tous les nombres : minutes, EUR ou une autre unité explicitement choisie. Les montants sont des nombres JSON, pas des chaînes de texte ; employer le point décimal. Des postes mensuels et annuels doivent être ramenés explicitement à la même période avant le calcul.

Accepter de zéro à 1 000 postes aux noms uniques de 1 à 100 caractères ; l'unité comporte de 1 à 32 caractères. Les libellés ne comportent pas d'espaces extérieurs. Chaque montant est fini, non négatif, au plus 1 000 000 000 000, avec au plus 28 chiffres et un exposant décimal de -12 à 12. Rejeter les booléens, les nombres sous forme de texte, les clés JSON répétées, les champs supplémentaires et les valeurs manquantes. L'entrée ne peut excéder 100 000 octets.

Une réserve supérieure au disponible est acceptée comme un budget impossible : elle produit un solde négatif même sans poste. Une liste vide permet de vérifier le seul effet de la réserve.

## Sortie et interprétation

Le calcul utilise les fractions exactes des nombres décimaux fournis. Les montants de sortie sont des chaînes décimales exactes, afin d'éviter un arrondi implicite par le lecteur JSON.

| Champ | Signification |
| --- | --- |
| `usable` | Disponible moins réserve |
| `total` | Somme des postes |
| `balance` | Disponible moins réserve moins total |
| `deficit` | Montant manquant, ou zéro |
| `unallocated` | Montant encore libre après réserve, ou zéro |
| `fits` | Vrai si le solde est positif ou nul |

L'exemple donne `usable: "50"`, `total: "90"`, `balance: "-40"`, `deficit: "40"`, `unallocated: "0"`, `fits: false`. Les 40 minutes manquantes comprennent les 30 minutes de dépassement initial et les 10 minutes de réserve ; ne pas ajouter à nouveau la réserve au manque.

Invocation dans un environnement autorisé : `python3 scripts/budget.py`, depuis le dossier de cette compétence, avec le JSON sur l'entrée standard. Une réussite produit `ok: true` et le code de sortie 0. Une erreur produit `ok: false` et le code 2 sans recopier l'entrée. Ne pas annoncer un calcul exécuté sans résultat observé.

## Procédure équivalente dans la conversation

1. Nommer l'unité et la période ; utiliser seulement les nombres fournis ou une hypothèse clairement annoncée.
2. Additionner les postes : dans l'exemple, `40 + 30 + 20 = 90 minutes`.
3. Retirer la réserve : `60 − 10 = 50 minutes utilisables`.
4. Calculer le solde : `50 − 90 = −40 minutes`, donc 40 minutes à reporter ou à réduire explicitement.
5. Proposer un arbitrage selon les échéances et les priorités connues. Une tâche peut être partiellement réalisée seulement si elle s'y prête et si le reste est indiqué. Une dépense obligatoire reste une contrainte.

Pour un budget fictif de dépenses : `100 EUR − 10 EUR de réserve − (19,99 EUR + 20,01 EUR) = 50 EUR encore libres`. Le calcul est identique ; les décisions de dépense restent celles d'Hélène.
