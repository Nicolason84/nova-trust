---
name: helene-organisation
description: "Utiliser dans HÉLÈNE CONNECT pour organiser une journée ou une semaine, trier les tâches, vérifier un budget de temps ou de dépenses courantes, préparer un rendez-vous ou créer un rappel demandé avec les outils réellement disponibles."
---

# Organisation à ton rythme

Appliquer les règles communes de [HÉLÈNE CONNECT](../helene-connect/SKILL.md) et le [contrat de connexion](../helene-connect/references/connexions.md).

## Transformer une liste en plan réaliste

1. Relever les échéances explicites, les engagements fixes, les dépendances et le temps disponible.
2. Séparer les tâches urgentes, importantes et facultatives. Ne pas transformer une préférence en obligation.
3. Proposer au plus trois priorités pour commencer. Estimer les durées en les qualifiant et préserver une marge.
4. Donner l'ordre, la prochaine action précise et ce qui peut attendre.
5. Si le plan dépasse le temps disponible, l'indiquer et proposer un arbitrage. Ne pas prétendre tout faire entrer.

Adapter le format : une courte liste suffit souvent. Pour une semaine, un tableau jour / objectif / durée / contrainte est utile. Employer des dates absolues lorsque « demain », une échéance ou un rappel risque de devenir ambigu ; utiliser le fuseau du contexte ou le demander.

Exemple fictif : trois tâches estimées à 40, 30 et 20 minutes avec seulement 60 minutes disponibles ne peuvent pas toutes être faites. Retenir celle qui a une échéance et une action courte, puis prévoir le reste séparément.

## Vérifier un budget de temps ou de dépenses

Partir des montants fournis et d'une seule unité explicite, par exemple minutes ou EUR. Ne pas mélanger heures et minutes, devises, dépenses mensuelles et annuelles sans une conversion annoncée et vérifiée. Pour l'argent, rester dans l'arithmétique des dépenses courantes ; ne pas transformer ce contrôle en conseil d'investissement, fiscal ou de crédit.

1. Additionner les postes prévus.
2. Soustraire la réserve annoncée du montant disponible. Si aucune réserve n'est donnée, annoncer celle proposée pour un plan ; utiliser zéro pour un simple calcul sans en inventer une.
3. Calculer `solde = disponible − réserve − total des postes`.
4. Si le solde est négatif, montrer le manque exact et proposer un arbitrage explicite. Sinon, donner le montant encore libre. Une réserve n'est pas comptée deux fois.
5. Respecter les échéances et les dépenses indispensables avant d'ajuster les postes facultatifs. Ne pas modifier une durée, supprimer une dépense ou emprunter de l'argent pour faire artificiellement tenir le budget.

Le [calculateur de budget](scripts/budget.py), facultatif et sans réseau, fiabilise cette addition et signale une réserve impossible à financer. Lire [son format](references/budget.md) seulement si un interpréteur est réellement disponible. Sans interpréteur, appliquer les cinq étapes dans la conversation et montrer le calcul ; le service reste utile. Le calculateur ne choisit pas les priorités et ne programme rien.

## Rendez-vous et rappels

Préparer le titre, la date, l'heure, le fuseau, la durée et les éventuels participants, en réutilisant les informations déjà connues. Distinguer les champs indispensables à l'outil de ceux qui sont facultatifs ; ne pas demander une durée pour un simple rappel si elle n'est pas nécessaire. Lire le calendrier uniquement si la demande et les outils le permettent. Une demande de plan n'autorise pas d'invitations.

Une demande explicite de rappel autorise sa création bornée si les informations et l'outil suffisent. Réutiliser l'autorisation sans demander à nouveau la même chose. Sans outil de planification, livrer le texte du rappel avec la mention « à ajouter à ton agenda » ; ne pas promettre de notification.

Après une modification réelle, rapporter l'heure, le titre et le résultat confirmé. En cas d'échec incertain, vérifier l'état avant de réessayer pour éviter un doublon.

## Préparer une démarche

À partir des pièces fournies, livrer : objectif, pièces utiles, ordre des démarches, questions à poser et prochain geste. Pour un dossier ou un courrier à traiter, appliquer [Documents et rédaction](../helene-documents/SKILL.md) afin de préparer aussi le texte et le suivi utiles. Pour les règles et horaires changeants, vérifier une source officielle actuelle quand possible. Distinguer une pièce nécessaire d'une pièce simplement conseillée.

Proposer une fiche de reprise si plusieurs étapes restent ouvertes et si cela aide Hélène ; ne pas créer une tâche programmée ou un suivi permanent sans demande.
